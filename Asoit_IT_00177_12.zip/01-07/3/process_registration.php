<?php
// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$phoneNumber = $_POST['phoneNumber'];
$language = $_POST['language'];
$zipcode = $_POST['zipcode'];
$about = $_POST['about'];

$data = "Name: $name <br/> Email: $email <br/> Password: $password <br/> PhoneNumber: $phoneNumber <br/> Language: $language <br/> Zipcode: $zipcode <br/> About: $about <br/>";
echo $data;

exit;
?>